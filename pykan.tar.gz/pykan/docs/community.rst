.. _community:

Community
---------

.. toctree::
   :maxdepth: 1
   
   Community/Community_1_physics_informed_kan.rst
   Community/Community_2_protein_sequence_classification.rst

   