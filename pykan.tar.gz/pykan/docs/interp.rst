.. _interp:

Interpretability
----------------

.. toctree::
   :maxdepth: 1
   
   Interp/Interp_1_Hello, MultKAN.rst
   Interp/Interp_2_Advanced MultKAN.rst
   Interp/Interp_3_KAN_Compiler.rst
   Interp/Interp_4_feature_attribution.rst
   Interp/Interp_5_test_symmetry.rst
   Interp/Interp_6_test_symmetry_NN.rst
   Interp/Interp_8_adding_auxillary_variables.rst
   Interp/Interp_9_different_plotting_metrics.rst
   Interp/Interp_10_hessian.rst
   Interp/Interp_10A_swap.rst
   Interp/Interp_10B_swap.rst
   Interp/Interp_11_sparse_init.rst
   

   