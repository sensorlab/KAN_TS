kan package
===========

kan.KAN module
--------------

.. automodule:: kan.MultKAN
   :members:
   :undoc-members:
   :show-inheritance:

kan.KANLayer module
-------------------

.. automodule:: kan.KANLayer
   :members:
   :undoc-members:
   :show-inheritance:

kan.LBFGS module
----------------

.. automodule:: kan.LBFGS
   :members:
   :undoc-members:
   :show-inheritance:

kan.Symbolic\_KANLayer module
-----------------------------

.. automodule:: kan.Symbolic_KANLayer
   :members:
   :undoc-members:
   :show-inheritance:

kan.spline module
-----------------

.. automodule:: kan.spline
   :members:
   :undoc-members:
   :show-inheritance:

kan.utils module
----------------

.. automodule:: kan.utils
   :members:
   :undoc-members:
   :show-inheritance:
   
kan.compiler module
-------------------

.. automodule:: kan.compiler
   :members:
   :undoc-members:
   :show-inheritance:
   
kan.hypothesis module
---------------------

.. automodule:: kan.hypothesis
   :members:
   :undoc-members:
   :show-inheritance:
