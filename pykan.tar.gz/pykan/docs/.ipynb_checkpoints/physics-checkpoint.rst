.. _physics:

Physics
-------

.. toctree::
   :maxdepth: 1
   
   Physics/Physics_1_Lagrangian.rst
   Physics/Physics_2A_conservation_law.rst
   Physics/Physics_2B_conservation_law_2D.rst
   Physics/Physics_3_blackhole.rst
   Physics/Physics_4A_constitutive_laws_P11.rst
   Physics/Physics_4B_constitutive_laws_P12_with_prior.rst
   Physics/Physics_4C_constitutive_laws_P12_without_prior.rst
   

   